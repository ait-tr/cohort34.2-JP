package de.ait.lesson06_dz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson06DzApplicationTests {

	@Test
	void contextLoads() {
	}

}
