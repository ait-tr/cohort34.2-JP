package de.ait.project.exceptions;

public class AdvertisementNotFoundException extends GeneralUnCheckedException {
    public AdvertisementNotFoundException(String msg) {
        super(msg);
    }
}
