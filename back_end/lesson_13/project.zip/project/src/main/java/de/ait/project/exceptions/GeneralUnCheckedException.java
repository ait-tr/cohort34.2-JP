package de.ait.project.exceptions;

public class GeneralUnCheckedException extends RuntimeException{
    GeneralUnCheckedException(String msg){
        super(msg);
    }
}
